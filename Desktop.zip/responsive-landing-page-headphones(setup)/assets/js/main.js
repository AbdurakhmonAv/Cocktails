/*=============== SHOW MENU ===============*/
const navMenu = document.getElementById("nav-menu"),
  navToggle = document.getElementById("nav-toggle"),
  navClose = document.getElementById("nav-close");

/*===== MENU SHOW =====*/
/* Validate if constant exists */
if (navToggle) {
  navToggle.addEventListener("click", (e) => {
    navMenu.classList.add("show-menu");
  });
}

/*==== MENU HIDE====*/
/* Validate if constant exists */
if (navClose) {
  navClose.addEventListener("click", (e) => {
    navMenu.classList.remove("show-menu");
  });
}

/*=============== REMOVE MENU MOBILE ===============*/
const navLink = document.querySelectorAll(".nav__link");

function removeNavMenu() {
  navMenu.classList.remove("show-menu");
}

navLink.forEach((link) =>
  link.addEventListener("click", (e) => {
    navLink.forEach((link) => link.classList.remove("active-link"));
    link.classList.add("active-link");
  })
);

navLink.forEach((link) =>
  link.addEventListener("click", (e) => {
    removeNavMenu();
  })
);

/*=============== CHANGE BACKGROUND HEADER ===============*/
const header = document.querySelector("#header");

window.addEventListener("scroll", () => {
  if (window.scrollY >= 50) header.classList.add("scroll-header");
  else header.classList.remove("scroll-header");
});

/*==================== SHOW SCROLL UP ====================*/

/*=============== SCROLL SECTIONS ACTIVE LINK ===============*/

/*=============== SCROLL REVEAL ANIMATION ===============*/
